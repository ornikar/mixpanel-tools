#!/bin/bash

zip -r dev-bundle/ornikarmixpaneltools.zip . -x '*.git*' -x '*dev-bundle*'